package mapNoturnoFactory;

class FabricaAsusNotebookGamer implements FabricaNotebookGamer {
    @Override
    public NotebookGamer criarNotebookGamer(String cor, String tamanhoTela, boolean tecladoRGB, String placaVideo, String processador) {
        return new AsusNotebookGamer(cor, tamanhoTela, tecladoRGB, placaVideo, processador);
    }
}