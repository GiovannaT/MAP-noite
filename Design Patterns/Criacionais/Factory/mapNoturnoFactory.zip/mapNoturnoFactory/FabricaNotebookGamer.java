package mapNoturnoFactory;

public interface FabricaNotebookGamer {
	NotebookGamer criarNotebookGamer(String cor, String tamanhoTela, boolean tecladoRGB, String placaVideo, String processador);
}
