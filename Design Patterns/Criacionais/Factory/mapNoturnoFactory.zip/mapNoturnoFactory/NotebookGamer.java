package mapNoturnoFactory;

public interface NotebookGamer {
	String getCor();
    String getTamanhoTela();
    boolean possuiTecladoRGB();
    String getPlacaVideo();
    String getProcessador();
}
