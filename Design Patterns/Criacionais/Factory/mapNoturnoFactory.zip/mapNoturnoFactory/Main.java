package mapNoturnoFactory;

public class Main {
	public static void main(String[] args) {
        
        FabricaNotebookGamer fabricaAsus = new FabricaAsusNotebookGamer();
        NotebookGamer asusNotebook = fabricaAsus.criarNotebookGamer("Preto", "15.6 polegadas", true, "NVIDIA GeForce RTX 3080", "Intel Core i9");
        System.out.println("Notebook ASUS:\n");
        System.out.println("Cor: " + asusNotebook.getCor());
        System.out.println("Tamanho da Tela: " + asusNotebook.getTamanhoTela());
        System.out.println("Possui Teclado RGB: " + asusNotebook.possuiTecladoRGB());
        System.out.println("Placa de Vídeo: " + asusNotebook.getPlacaVideo());
        System.out.println("Processador: " + asusNotebook.getProcessador());

        FabricaNotebookGamer fabricaMsi = new FabricaMsiNotebookGamer();
        NotebookGamer msiNotebook = fabricaMsi.criarNotebookGamer("Vermelho", "17 polegadas", false, "NVIDIA GeForce RTX 3070", "AMD Ryzen 9");
        System.out.println("\nNotebook MSI:\n");
        System.out.println("Cor: " + msiNotebook.getCor());
        System.out.println("Tamanho da Tela: " + msiNotebook.getTamanhoTela());
        System.out.println("Possui Teclado RGB: " + msiNotebook.possuiTecladoRGB());
        System.out.println("Placa de Vídeo: " + msiNotebook.getPlacaVideo());
        System.out.println("Processador: " + msiNotebook.getProcessador());
    }
}