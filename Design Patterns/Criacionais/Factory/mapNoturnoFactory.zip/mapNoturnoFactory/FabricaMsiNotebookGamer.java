package mapNoturnoFactory;

class FabricaMsiNotebookGamer implements FabricaNotebookGamer {
    @Override
    public NotebookGamer criarNotebookGamer(String cor, String tamanhoTela, boolean tecladoRGB, String placaVideo, String processador) {
        return new MsiNotebookGamer(cor, tamanhoTela, tecladoRGB, placaVideo, processador);
    }
}
