package mapNoturnoFactory;

class AsusNotebookGamer implements NotebookGamer {
	private String cor;
    private String tamanhoTela;
    private boolean tecladoRGB;
    private String placaVideo;
    private String processador;

    public AsusNotebookGamer(String cor, String tamanhoTela, boolean tecladoRGB, String placaVideo, String processador) {
        this.cor = cor;
        this.tamanhoTela = tamanhoTela;
        this.tecladoRGB = tecladoRGB;
        this.placaVideo = placaVideo;
        this.processador = processador;
    }

    @Override
    public String getCor() {
        return cor;
    }

    @Override
    public String getTamanhoTela() {
        return tamanhoTela;
    }

    @Override
    public boolean possuiTecladoRGB() {
        return tecladoRGB;
    }

    @Override
    public String getPlacaVideo() {
        return placaVideo;
    }

    @Override
    public String getProcessador() {
        return processador;
    }
}
